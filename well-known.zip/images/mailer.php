 <head>
<title>XnoonDZ Priv8 Mailer</title>
<center>
<form method=post action="">
<H2>PR1V8 M4IL3R BY XnoonDZ MUSLIIM</H2>
<input type="text" value="<?php if(isset($_POST['sendername'])){echo $_POST['sendername']; } ?>" placeholder="sender name" name="sendername">
<input type="text" value="<?php if(isset($_POST['sendermail'])){echo $_POST['sendermail']; } ?>" placeholder="sender mail" name="sendermail"><BR/><BR/>
<input type="text" placeholder="Subject"  size="40" value="<?php if(isset($_POST['subject'])){echo $_POST['subject']; } ?>" name="subject"><BR/><BR/>

<textarea style="width:500px;height:100px;" name="letter" placeholder="PUT LETTER HERE"><?php if(isset($_POST['letter'])){echo $_POST['letter']; } ?>
</textarea><BR/><BR/>

<textarea style="width:500px;height:100px;" name="mailist" placeholder="PUT MAILIST HERE"><?php if(isset($_POST['mailist'])){echo $_POST['mailist']; } ?>
</textarea><BR/><BR/>
<b>Second to wait between each send</b>&nbsp;
<input type="text"   size="4"value="<?php if(isset($_POST['sleep'])){echo $_POST['sleep']; }else{echo "0"; } ?>" name="sleep"><BR/><BR/>

<input type="submit" name="submit" value="GET R3ZULTS FROM XnoonDZ"/>


</form>



<?php if(isset($_POST['submit'])){
$nama=$_POST['sendername'];
$nama1=$_POST['sendermail'];
$random = rand(0,100000).$_SERVER['REMOTE_ADDR'];
$dst    = substr(md5($random), 0, 10);
$emailer = str_replace('[rand]', $dst, $nama1);
$sender= $nama.'<'.$emailer.'>';
$headers .= 'From: '.$sender. "\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

$subject= $_POST['subject'];
$letter = $_POST['letter'];
$mailist = $_POST['mailist'];
$to      = $mailist;
$message = $letter;




$line = 0;
$tLignes = explode("\n",$_POST['mailist']);
foreach ($tLignes as $em){ 
$line = $line+1;
}
?>
<H4>Total emails : <?php echo $line; ?> </H4>
<?php
$spamed = 0;
foreach ($tLignes as $em){ 

$spamed = $spamed+1;

if(mail($em, $subject, $message, $headers)){
echo "SPAMED ".$spamed."/".$line." =><b>".$em."</b> => INBOX <i>email : ".$emailer."</i><BR>"; 
}
sleep($_POST['sleep']);
}


}

?>

</center>

